package com.oop.eventTickeingSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventTickeingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventTickeingSystemApplication.class, args);
	}

}
